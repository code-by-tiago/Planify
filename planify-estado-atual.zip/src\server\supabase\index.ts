export const supabaseServerModule = {
  name: "supabase",
  status: "prepared",
  requiredEnv: [
    "NEXT_PUBLIC_SUPABASE_URL",
    "NEXT_PUBLIC_SUPABASE_ANON_KEY",
    "SUPABASE_SERVICE_ROLE_KEY",
  ],
} as const;